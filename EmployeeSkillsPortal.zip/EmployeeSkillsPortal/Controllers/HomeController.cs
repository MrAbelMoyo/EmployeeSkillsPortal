using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Security.Claims;
using EmployeeSkillsPortal.Data;
using EmployeeSkillsPortal.Models;
using System.Linq;

namespace EmployeeSkillsPortal.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize]
        public IActionResult Dashboard()
        {
            return View();
        }

        public IActionResult Login()
        {
            return Challenge(new AuthenticationProperties { RedirectUri = "/Home/Dashboard" }, OpenIdConnectDefaults.AuthenticationScheme);
        }

        public IActionResult Logout()
        {
            return SignOut(new AuthenticationProperties { RedirectUri = "/" }, OpenIdConnectDefaults.AuthenticationScheme, "Cookies");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [Authorize]
        public IActionResult PersonalInformation()
        {
            var indexNumber = User.FindFirst("IndexNumber")?.Value; // Assuming "IndexNumber" is the claim name
            var staff = _context.Staffs.FirstOrDefault(s => s.IndexNumber == indexNumber);

            return View(staff);
        }

        [Authorize]
        public IActionResult ExamplesOfProjects()
        {
            var indexNumber = User.FindFirst("IndexNumber")?.Value; // Assuming "IndexNumber" is the claim name
            var projects = _context.Projects.Where(p => p.Staff.IndexNumber == indexNumber).ToList();

            return View(projects);
        }

        [Authorize]
        public IActionResult SoftwareExpertise()
        {
            var indexNumber = User.FindFirst("IndexNumber")?.Value; // Assuming "IndexNumber" is the claim name
            var expertise = _context.SoftwareExpertises.Where(e => e.Staff.IndexNumber == indexNumber).ToList();

            return View(expertise);
        }

        [Authorize]
        public IActionResult Languages()
        {
            var indexNumber = User.FindFirst("IndexNumber")?.Value; // Assuming "IndexNumber" is the claim name
            var languages = _context.Languages.Where(l => l.Staff.IndexNumber == indexNumber).ToList();

            return View(languages);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = HttpContext.TraceIdentifier });
        }
    }
}
