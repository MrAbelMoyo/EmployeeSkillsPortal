using System.ComponentModel.DataAnnotations;

namespace EmployeeSkillsPortal.Models
{
    public class SoftwareExpertise
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string SoftwareExpertiseName { get; set; }

        [Required]
        public string SoftwareExpertiseLevel { get; set; }

        public int StaffId { get; set; }
        public Staff Staff { get; set; }
    }
}
