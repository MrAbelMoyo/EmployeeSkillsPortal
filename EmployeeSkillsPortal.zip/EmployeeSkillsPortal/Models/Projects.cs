using System.ComponentModel.DataAnnotations;

namespace EmployeeSkillsPortal.Models
{
    public class Project
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string ProjectTitleAndLocation { get; set; }

        [Required]
        public string LevelOfResponsibility { get; set; }

        [Required]
        public string BriefDescriptionOfRole { get; set; }

        public int StaffId { get; set; }
        public Staff Staff { get; set; }
    }
}
