// Staff.cs in EmployeeSkillsPortal.Models namespace
using System.ComponentModel.DataAnnotations;

namespace EmployeeSkillsPortal.Models
{
    public class Staff
    {
        public int Id { get; set; }

        [Required]
        public string IndexNumber { get; set; }

        [Required]
        public string FullNames { get; set; }

        // Add other properties as needed

        // Navigation properties
        public ICollection<Project> Projects { get; set; }
        public ICollection<SoftwareExpertise> SoftwareExpertises { get; set; }
        public ICollection<Language> Languages { get; set; }
    }
}
