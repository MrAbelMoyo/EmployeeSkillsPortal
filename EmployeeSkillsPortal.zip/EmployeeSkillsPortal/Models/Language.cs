using System.ComponentModel.DataAnnotations;

namespace EmployeeSkillsPortal.Models
{
    public class Language
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string LanguageName { get; set; }

        [Required]
        public string LevelOfResponsibility { get; set; }

        public int StaffId { get; set; }
        public Staff Staff { get; set; }
    }
}
